'''
4. POO

    Crear un programa en lenguaje Python donde se use la POO.

Definir una clase llamada Persona con los atributos nombre, edad y DNI y con los siguientes métodos:

    - Un constructor, donde los datos pueden estar vacíos.
    - Los métodos para manejar cada uno de los atributos (setters y getters). Hay que validar las entradas de datos (nombre no puede estar vacío, edad > 0, dni de 9 caracteres y con la letra correcta).
    - El método __str__ para mostrar todos los datos de la persona.
    - El método esMayorDeEdad(): Devuelve un valor lógico indicando si es mayor de edad.

En el programa principal se debe pedir los datos de 2 personas, crear los objetos correspondientes, indicar si son mayores de edad y mostrar los datos de la persona con mayor edad.
'''
class Persona:
    def __init__(self,nombre,edad,dni):
        #self.nombre=nombre
        self.setnombre(nombre)
        #self.edad=edad
        self.setedad(edad)
        #self.dni=dni
        self.setdni(dni)
        return

    def __str__(self):
         return '{} {} {}'.format(self.nombre, str(self.edad), self.dni)
    
    def esMayorDeEdad(self):
        mayor=False
        if self.edad>=18:
            mayor=True
        return mayor

    def getnombre(self):
        return self.nombre
  
    def setnombre(self, nombre):
        if nombre!='':
            self.nombre = nombre
        else:
            raise ValueError("Nombre no puede estar vacio")
        #self.nombre = nombre
    
    def getedad(self):
        return self.edad
  
    def setedad(self, edad):
        if edad>0:
            self.edad = edad
        else:
            raise ValueError("Edad debe ser mayor a 0")
        #elf.edad = edad

    def getdni(self):
        return self.dni
  
    def setdni(self, dni):
        tabla = "TRWAGMYFPDXBNJZSQVHLCKE"
        numeros = "1234567890"
        if (len(dni) == 9):
            letraControl = dni[8].upper()
            dni = dni[:8]
            if ( len(dni) == len( [n for n in dni if n in numeros] ) ):
                if tabla[int(dni)%23] == letraControl:
                    self.dni = dni
                else:
                   raise ValueError("DNI error")
        else:
            raise ValueError("DNI error")

        #self.dni = dni

nombreP1=input("Nombre de la persona 1:")
edadP1=int(input("Edad de la persona 1:"))
dniP1=input("DNI de la persona 1:")

nombreP2=input("Nombre de la persona 2:")
edadP2=int(input("Edad de la persona 2:"))
dniP2=input("DNI de la persona 2:")

p1=Persona(nombreP1,edadP1,dniP1)
p2=Persona(nombreP2,edadP2,dniP2)

if p1.esMayorDeEdad():
    print("La persona 1 es mayor de Edad")
else:
    print("La persona 1 es menor de Edad")

if p2.esMayorDeEdad():
    print("La persona 2 es mayor de Edad")
else:
    print("La persona 2 es menor de Edad")

if p1.getedad() > p2.getedad():
    print(p1)
elif p1.getedad() < p2.getedad():
    print(p2)
elif p1.getedad()==p2.getedad():
    print(p1,p2)

