lista_original=[]
lista_ordenada=[]
valor=1

while valor != 0:
    valor=int(input("introduce numero:"))
    lista_original.append(valor)

def ordenar_lista_primos(lista):  
    for i in lista: 
        for n in range(2,i):
            if i % n==0:
                break
            else:
                lista_ordenada.append(i)
                break


print(lista_original)
ordenar_lista_primos(lista_original)
print(sorted(lista_ordenada,reverse=False))



