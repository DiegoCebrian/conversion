#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec  5 17:08:49 2021

@author: diego
"""
num= int(input("Introduce numero: "))
#Voy desde el numero que meto hasta 
while num >0:
    #saco el cuadrado del numero y lo paso a string
    #para luego jugar con la longitudes
    cuadrado=str(num**2)
    #saco la longituda del cuadrado para ir de la mitad hasta
    #el principio y de la mitad hasta el final
    longi=len(cuadrado)
    #si el numero es igual a la suma de las mitdas lo saco por
    #pantalla
    if (num)==int('0'+cuadrado[:longi//2])+int(cuadrado[longi//2:]):
        print(num)
    num=num-1
