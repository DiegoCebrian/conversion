#creo el diccionario vacio
vehiculos={}

#inicializo la opcion del menu con un entro
op_menu=0

#mientras la opcion no sea 7 voy a seguir pidiendo opciones
while op_menu!=7:
  if op_menu==1:
    #Añadir un vehículo al diccionario con todos sus datos.
    #la matricula es la clave
    matricula=input("Matricula: ")
    nom_conductor=input("Conductor: ")
    marca=input("Marca: ")
    modelo=input("Modelo: ")
    km=input("Km: ")
    fec_matri=input("Fecha matriculacion: ")
    
    #añado al diccionario, me tengo que creao otro diccionario con los datos del vehiculo, cuando lo tenga lo añado a vehiculo cuya clave es matricula
    vehiculo={"nom_conductor":nom_conductor,"marca":marca,"modelo":modelo,"km":km,"fec_matri":fec_matri}
    vehiculos[matricula]=vehiculo

  if op_menu==2:
    #Mostrar todos las matrículas con los nombres de sus conductores.
    for clave, vehiculo in vehiculos.items():
            print(clave, vehiculo['nom_conductor'])
    
  if op_menu==3:
    #Me creo una lista donde y la lleno con tuplas, matricula fecha matri
    lista_Matri_Fecha=[]
    for clave, vehiculo in vehiculos.items():   
      lista_Matri_Fecha.append((clave,vehiculo["fec_matri"]))
    #print(lista_Matri_Fecha)
    
    #me defino otra lista donde voy a guardar la lista anterior ordenada
    matriculas_ordenadas=sorted(lista_Matri_Fecha, key=lambda lista_Matri_Fecha: lista_Matri_Fecha[1])
    print(matriculas_ordenadas)

  if op_menu==4:
    #Pedir una marca y mostrar las matrículas de los vehículos de dicha marca.
    marca=input("Marca?: ")

    for clave,vehiculo in vehiculos.items():
      if vehiculo['marca']== marca:
        print(clave.title()+':',vehiculo['nom_conductor'])

  if op_menu==5:
    #Obtener los nombres de los conductores sin que se repita ninguno.
    nombres=[]
    for clave,vehiculo in vehiculos.items():
            #print(vehiculo['nom_conductor'])
            if vehiculo['nom_conductor']  not in nombres:
                nombres.append(vehiculo['nom_conductor'])
    print(nombres)

  if op_menu==6:
    #Obtener los nombres de los conductores que conducen más de un vehículo y cuántos vehículos conducen.
    conductores={}
    for clave,vehiculo in vehiculos.items():     
      if vehiculo["nom_conductor"] not in conductores.keys():
        conductores[vehiculo["nom_conductor"]]=1
      else:
        conductores[vehiculo["nom_conductor"]]= conductores[vehiculo["nom_conductor"]]+1

    print("Los conductores y el numero de vehiculos que conducen son: ",conductores)
  
  op_menu=int(input("*--Opciones---* \n 1-> Añadir un vehículo al diccionario con todos sus datos. \n 2-> Mostrar todos las matrículas con los nombres de sus conductores. \n 3-> Mostrar todos las matrículas ordenadas alfabéticamente por fecha de matriculación. \n 4-> Pedir una marca y mostrar las matrículas de los vehículos de dicha marca. \n 5-> Obtener los nombres de los conductores sin que se repita ninguno. \n 6-> Obtener los nombres de los conductores que conducen más de un vehículo y cuántos vehículos conducen. \n 7-> Terminar \n Tu opcion): "))
